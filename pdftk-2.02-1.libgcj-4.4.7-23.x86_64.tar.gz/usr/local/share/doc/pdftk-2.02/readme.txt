PDFtk Server (pdftk) is not public domain software. It is licensed to the public under the GNU General Public License (GPL) as described in the license_gpl_pdftk folder. Pdftk uses third-party libraries which have their own licenses. The exact licensing terms can be found in the third_party folder and on the pdftk license web page: www.pdflabs.com/docs/pdftk-license/. Source code for pdftk and for these third-party libraries is available from this same page.

If you want to distribute pdftk as part of your own software, you will need a commercial license. The exception to this rule is if your software is licensed to the public under the GPL or another compatible license.

Commercial licenses are available for pdftk. They include commercial-grade support and allow commercial redistribution. Please email sid.steward@pdflabs.com to learn more. And please include pdftk in your email subject. Thank you.
